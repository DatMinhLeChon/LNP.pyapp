# Linear_programing.pyapp
Python application development
*API
- tkinter
- tksheet
- scipy API
- pandas
- numpy
# Documentation:
*scipy API
- link: https://docs.scipy.org/doc//scipy/index.html
*tkinter
- link: https://docs.python.org/3/library/tkinter.html
# Running
run this command in LNP.pyapp project : 
 "python main.py"
 


